create database cybercrimeanalytics;
use cybercrimeanalytics;

CREATE TABLE dim_state_ut (
  state_ut_code VARCHAR(10) PRIMARY KEY,
  state_ut_name VARCHAR(100) NOT NULL,
  type VARCHAR(30),                  -- 'State' or 'Union Territory'
  capital VARCHAR(100)
);

CREATE TABLE dim_city (
  city_id VARCHAR(20) PRIMARY KEY,
  city_name VARCHAR(100) NOT NULL,
  urban_rural_flag ENUM('Urban', 'Rural'),
  state_ut_code VARCHAR(10),
  FOREIGN KEY (state_ut_code) REFERENCES dim_state_ut(state_ut_code)
);

TRUNCATE TABLE dim_city;

SELECT 
    TABLE_NAME, 
    CONSTRAINT_NAME, 
    REFERENCED_TABLE_NAME 
FROM 
    INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE 
    REFERENCED_TABLE_NAME = 'dim_city';
    
    SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE dim_city;
SET FOREIGN_KEY_CHECKS = 1;


DELETE FROM dim_city;

DELETE FROM dim_city WHERE 1 = 1;


SET SQL_SAFE_UPDATES = 0;
DELETE FROM dim_city;
SET SQL_SAFE_UPDATES = 1;

















CREATE TABLE dim_agency (
  agency_id VARCHAR(20) PRIMARY KEY,
  investigating_agency VARCHAR(150) NOT NULL,
  city_id VARCHAR(20),
  FOREIGN KEY (city_id) REFERENCES dim_city(city_id)
);


SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE dim_agency;
SET FOREIGN_KEY_CHECKS = 1;


DELETE FROM dim_agency;

DELETE FROM dim_agency WHERE 1 = 1;


SET SQL_SAFE_UPDATES = 0;
DELETE FROM dim_agency;
SET SQL_SAFE_UPDATES = 1;














CREATE TABLE dim_device (
  device_id VARCHAR(20) PRIMARY KEY,
  device_type VARCHAR(50),
  os_type VARCHAR(50),
  is_vpn_used ENUM('Yes', 'No')
);

CREATE TABLE dim_crime_type (
  crime_type_id VARCHAR(20) PRIMARY KEY,
  crime_type VARCHAR(100) NOT NULL,
  cybercrime_category VARCHAR(100),
  modus_operandi VARCHAR(255),
  platform_used VARCHAR(100)
);

CREATE TABLE dim_victim (
  victim_id VARCHAR(20) PRIMARY KEY,
  age INT,
  gender ENUM('Male', 'Female', 'Other'),
  occupation VARCHAR(100),
  income_group VARCHAR(50),
  education_level VARCHAR(100)
);

CREATE TABLE fact_cybercrime_incident (
  incident_id VARCHAR(30) PRIMARY KEY,
  incident_date DATE,
  fir_number VARCHAR(50),
  city_id VARCHAR(20),
  crime_type_id VARCHAR(20),
  victim_id VARCHAR(20),
  device_id VARCHAR(20),
  agency_id VARCHAR(20),
  loss_amount DECIMAL(12,2),
  recovered_amount DECIMAL(12,2),
  arrest_made ENUM('Yes', 'No'),
  repeat_offender ENUM('Yes', 'No'),
  status VARCHAR(50),

  FOREIGN KEY (city_id) REFERENCES dim_city(city_id),
  FOREIGN KEY (crime_type_id) REFERENCES dim_crime_type(crime_type_id),
  FOREIGN KEY (victim_id) REFERENCES dim_victim(victim_id),
  FOREIGN KEY (device_id) REFERENCES dim_device(device_id),
  FOREIGN KEY (agency_id) REFERENCES dim_agency(agency_id)
);


show variables like "secure_file_priv";
load data infile "C:/ProgramData/MySQL/MySQL Server 8.4/Uploads/fact_cybercrime_incident.csv" into table fact_cybercrime_incident
fields terminated by ","
ignore 1 lines;

select * from dim_state_ut;
select * from dim_city;
select * from dim_agency;
select * from dim_device;
select * from dim_crime_type;
select * from dim_victim;

UPDATE dim_victim
SET gender = 'Others'
WHERE gender = 'Other';

ALTER TABLE dim_victim
MODIFY gender ENUM('Male', 'Female', 'Other', 'Others');


UPDATE dim_victim
SET gender = 'Others'
WHERE gender = 'Other';

SELECT DISTINCT gender FROM dim_victim;






select * from fact_cybercrime_incident;

#I. BASIC LEVEL (Data Retrieval & Filtering)
#II. INTERMEDIATE LEVEL (Aggregations & Counts)
#III. ADVANCED LEVEL (Joins & Relationships)
#IV. ANALYTICAL / INSIGHT-BASED QUERIES
#V. REAL-TIME APPLICATION / ADMIN OPERATIONS


#1. Display all cybercrime incidents
DELIMITER //
CREATE PROCEDURE GetAllCybercrimeIncidents()
BEGIN
    SELECT 
        incident_id,
        incident_date,
        fir_number,
        city_id,
        crime_type_id,
        victim_id,
        device_id,
        agency_id,
        loss_amount,
        recovered_amount,
        arrest_made,
        repeat_offender,
        status
    FROM fact_cybercrime_incident;
END //
DELIMITER ;

#2. Retrieve all cities from a specific state or union territory (input: state_ut_code)
DELIMITER //
CREATE PROCEDURE GetCitiesByStateUT(IN p_state_ut_code VARCHAR(10))
BEGIN
    SELECT 
        city_id,
        city_name,
        urban_rural_flag,
        state_ut_code
    FROM dim_city
    WHERE state_ut_code = p_state_ut_code;
END //
DELIMITER ;

#3. Display all cases where arrest_made = 'Yes'
DELIMITER //
CREATE PROCEDURE GetArrestedCases()
BEGIN
    SELECT *
    FROM fact_cybercrime_incident
    WHERE arrest_made = 'Yes';
END //
DELIMITER ;

#4. Fetch incidents handled by a particular investigating agency
DELIMITER //
CREATE PROCEDURE GetIncidentsByAgency(IN p_agency_name VARCHAR(150))
BEGIN
    SELECT 
        f.incident_id,
        f.incident_date,
        f.loss_amount,
        f.recovered_amount,
        f.status,
        a.investigating_agency
    FROM fact_cybercrime_incident f
    JOIN dim_agency a ON f.agency_id = a.agency_id
    WHERE a.investigating_agency = p_agency_name;
END //
DELIMITER ;

#5. Show all victims with a specific gender
DELIMITER //
CREATE PROCEDURE GetVictimsByGender(IN p_gender ENUM('Male','Female','Other'))
BEGIN
    SELECT 
        victim_id,
        age,
        gender,
        occupation,
        income_group,
        education_level
    FROM dim_victim
    WHERE gender = p_gender;
END //
DELIMITER ;

#6. List all unique cybercrime_category values from dim_crime_type
DELIMITER //
CREATE PROCEDURE GetUniqueCybercrimeCategories()
BEGIN
    SELECT DISTINCT cybercrime_category
    FROM dim_crime_type
    WHERE cybercrime_category IS NOT NULL AND cybercrime_category <> '';
END //
DELIMITER ;

#7. Display all cases involving a specific device_type
DELIMITER //
CREATE PROCEDURE GetIncidentsByDeviceType(IN p_device_type VARCHAR(50))
BEGIN
    SELECT 
        f.incident_id,
        f.incident_date,
        f.loss_amount,
        f.recovered_amount,
        d.device_type,
        d.os_type
    FROM fact_cybercrime_incident f
    JOIN dim_device d ON f.device_id = d.device_id
    WHERE d.device_type = p_device_type;
END //
DELIMITER ;

#8. Show crimes reported between two dates (inputs: start_date, end_date)
DELIMITER //
CREATE PROCEDURE GetCrimesByDateRange(IN p_start_date DATE, IN p_end_date DATE)
BEGIN
    SELECT *
    FROM fact_cybercrime_incident
    WHERE incident_date BETWEEN p_start_date AND p_end_date;
END //
DELIMITER ;

#9. Retrieve all incidents from a given city_name
DELIMITER //
CREATE PROCEDURE GetIncidentsByCityName(IN p_city_name VARCHAR(100))
BEGIN
    SELECT 
        f.incident_id,
        f.incident_date,
        f.loss_amount,
        f.recovered_amount,
        c.city_name,
        f.status
    FROM fact_cybercrime_incident f
    JOIN dim_city c ON f.city_id = c.city_id
    WHERE c.city_name = p_city_name;
END //
DELIMITER ;

#10. List all crimes where is_vpn_used = 'Yes'
DELIMITER //
CREATE PROCEDURE GetVPNUsedCrimes()
BEGIN
    SELECT 
        f.incident_id,
        f.incident_date,
        f.loss_amount,
        f.recovered_amount,
        d.device_type,
        d.os_type,
        d.is_vpn_used
    FROM fact_cybercrime_incident f
    JOIN dim_device d ON f.device_id = d.device_id
    WHERE d.is_vpn_used = 'Yes';
END //
DELIMITER ;


#How to Call Them
CALL GetAllCybercrimeIncidents();
CALL GetCitiesByStateUT('AP');
CALL GetArrestedCases();
CALL GetIncidentsByAgency('Cyber Crime Cell, Morbi');
CALL GetVictimsByGender('Female');
CALL GetUniqueCybercrimeCategories();
CALL GetIncidentsByDeviceType('Laptop');
CALL GetCrimesByDateRange('2023-01-01', '2023-12-31');
CALL GetIncidentsByCityName('Hyderabad');
CALL GetVPNUsedCrimes();

#II. INTERMEDIATE LEVEL (Aggregations & Counts)

#1. Count total cybercrime incidents in India
DELIMITER //
CREATE PROCEDURE CountTotalCybercrimes()
BEGIN
    SELECT COUNT(*) AS total_cybercrime_incidents
    FROM fact_cybercrime_incident;
END //
DELIMITER ;

#2. Count incidents per state_ut_name
DELIMITER //
CREATE PROCEDURE CountIncidentsPerState()
BEGIN
    SELECT 
        s.state_ut_name,
        COUNT(*) AS total_incidents
    FROM fact_cybercrime_incident f
    JOIN dim_city c ON f.city_id = c.city_id
    JOIN dim_state_ut s ON c.state_ut_code = s.state_ut_code
    GROUP BY s.state_ut_name
    ORDER BY total_incidents DESC;
END //
DELIMITER ;

#3. Calculate total loss_amount and recovered_amount
DELIMITER //
CREATE PROCEDURE TotalLossAndRecovery()
BEGIN
    SELECT 
        SUM(loss_amount) AS total_loss_amount,
        SUM(recovered_amount) AS total_recovered_amount
    FROM fact_cybercrime_incident;
END //
DELIMITER ;

#4. Number of incidents per crime_type
DELIMITER //
CREATE PROCEDURE IncidentsPerCrimeType()
BEGIN
    SELECT 
        ct.crime_type,
        COUNT(*) AS total_incidents
    FROM fact_cybercrime_incident f
    JOIN dim_crime_type ct ON f.crime_type_id = ct.crime_type_id
    GROUP BY ct.crime_type
    ORDER BY total_incidents DESC;
END //
DELIMITER ;

#5. Total cases handled by each agency
DELIMITER //
CREATE PROCEDURE CasesPerAgency()
BEGIN
    SELECT 
        a.agency_id,
        a.investigating_agency,
        COUNT(*) AS total_cases_handled
    FROM fact_cybercrime_incident f
    JOIN dim_agency a ON f.agency_id = a.agency_id
    GROUP BY a.agency_id, a.investigating_agency
    ORDER BY total_cases_handled DESC;
END //
DELIMITER ;

#6. Percentage of repeat_offender = 'Yes'
DELIMITER //
CREATE PROCEDURE RepeatOffenderPercentage()
BEGIN
    SELECT 
        CONCAT(
            ROUND(
                (SUM(CASE WHEN repeat_offender = 'Yes' THEN 1 ELSE 0 END) / COUNT(*)) * 100, 
                2
            ), '%'
        ) AS repeat_offender_percentage
    FROM fact_cybercrime_incident;
END //
DELIMITER ;

#7. Top 5 cities with highest number of cybercrime incidents
DELIMITER //
CREATE PROCEDURE Top5CitiesByIncidents()
BEGIN
    SELECT 
        c.city_name,
        COUNT(*) AS total_incidents
    FROM fact_cybercrime_incident f
    JOIN dim_city c ON f.city_id = c.city_id
    GROUP BY c.city_name
    ORDER BY total_incidents DESC
    LIMIT 5;
END //
DELIMITER ;

#8. Total cases by urban_rural_flag
DELIMITER //
CREATE PROCEDURE CasesByUrbanRuralFlag()
BEGIN
    SELECT 
        c.urban_rural_flag,
        COUNT(*) AS total_cases
    FROM fact_cybercrime_incident f
    JOIN dim_city c ON f.city_id = c.city_id
    GROUP BY c.urban_rural_flag;
END //
DELIMITER ;

#9. Average loss_amount per state_ut_name
DELIMITER //
CREATE PROCEDURE AvgLossPerState()
BEGIN
    SELECT 
        s.state_ut_name,
        ROUND(AVG(f.loss_amount), 2) AS avg_loss_amount
    FROM fact_cybercrime_incident f
    JOIN dim_city c ON f.city_id = c.city_id
    JOIN dim_state_ut s ON c.state_ut_code = s.state_ut_code
    GROUP BY s.state_ut_name
    ORDER BY avg_loss_amount DESC;
END //
DELIMITER ;

#10. List all cities where total loss_amount exceeds ₹10,00,000
DELIMITER //
CREATE PROCEDURE CitiesWithHighLoss()
BEGIN
    SELECT 
        c.city_name,
        SUM(f.loss_amount) AS total_loss_amount
    FROM fact_cybercrime_incident f
    JOIN dim_city c ON f.city_id = c.city_id
    GROUP BY c.city_name
    HAVING total_loss_amount > 1000000
    ORDER BY total_loss_amount DESC;
END //
DELIMITER ;

CALL CountTotalCybercrimes();
CALL CountIncidentsPerState();
CALL TotalLossAndRecovery();
CALL IncidentsPerCrimeType();
CALL CasesPerAgency();
CALL RepeatOffenderPercentage();
CALL Top5CitiesByIncidents();
CALL CasesByUrbanRuralFlag();
CALL AvgLossPerState();
CALL CitiesWithHighLoss();

#III. ADVANCED LEVEL (Joins & Relationships)

#1. Show incidents with details from all related dimension tables (full joined view)
DELIMITER //
CREATE PROCEDURE FullIncidentDetails()
BEGIN
    SELECT 
        f.incident_id,
        f.incident_date,
        f.fir_number,
        c.city_name,
        s.state_ut_name,
        ct.crime_type,
        ct.cybercrime_category,
        v.gender,
        v.age,
        v.occupation,
        v.education_level,
        d.device_type,
        d.os_type,
        a.investigating_agency,
        f.loss_amount,
        f.recovered_amount,
        f.arrest_made,
        f.repeat_offender,
        f.status
    FROM fact_cybercrime_incident f
    JOIN dim_city c        ON f.city_id = c.city_id
    JOIN dim_state_ut s    ON c.state_ut_code = s.state_ut_code
    JOIN dim_crime_type ct ON f.crime_type_id = ct.crime_type_id
    JOIN dim_victim v      ON f.victim_id = v.victim_id
    JOIN dim_device d      ON f.device_id = d.device_id
    JOIN dim_agency a      ON f.agency_id = a.agency_id;
END //
DELIMITER ;

#2. Fetch all crimes under a specific cybercrime_category
DELIMITER //
CREATE PROCEDURE CrimesByCategory(IN p_category VARCHAR(100))
BEGIN
    SELECT 
        f.incident_id,
        f.incident_date,
        ct.crime_type,
        ct.cybercrime_category,
        f.loss_amount,
        f.status
    FROM fact_cybercrime_incident f
    JOIN dim_crime_type ct ON f.crime_type_id = ct.crime_type_id
    WHERE ct.cybercrime_category = p_category;
END //
DELIMITER ;

#3. Show all victims along with their state and city names
DELIMITER //
CREATE PROCEDURE VictimsWithLocation()
BEGIN
    SELECT DISTINCT
        v.victim_id,
        v.age,
        v.gender,
        v.occupation,
        v.education_level,
        c.city_name,
        s.state_ut_name
    FROM dim_victim v
    JOIN fact_cybercrime_incident f ON v.victim_id = f.victim_id
    JOIN dim_city c ON f.city_id = c.city_id
    JOIN dim_state_ut s ON c.state_ut_code = s.state_ut_code;
END //
DELIMITER ;

#4. Show each device_type with number of incidents
DELIMITER //
CREATE PROCEDURE DeviceTypeUsageCount()
BEGIN
    SELECT 
        d.device_type,
        COUNT(*) AS total_incidents
    FROM fact_cybercrime_incident f
    JOIN dim_device d ON f.device_id = d.device_id
    GROUP BY d.device_type
    ORDER BY total_incidents DESC;
END //
DELIMITER ;

#5. Top 3 investigating_agencies by number of closed cases
DELIMITER //
CREATE PROCEDURE Top3AgenciesByClosedCases()
BEGIN
    SELECT 
        a.investigating_agency,
        COUNT(*) AS closed_cases
    FROM fact_cybercrime_incident f
    JOIN dim_agency a ON f.agency_id = a.agency_id
    WHERE f.status = 'Closed'
    GROUP BY a.investigating_agency
    ORDER BY closed_cases DESC
    LIMIT 3;
END //
DELIMITER ;

#6. Display incidents grouped by status for a given state_ut_code
DELIMITER //
CREATE PROCEDURE IncidentsByStatusInState(IN p_state_ut_code VARCHAR(10))
BEGIN
    SELECT 
        f.status,
        COUNT(*) AS total_incidents
    FROM fact_cybercrime_incident f
    JOIN dim_city c ON f.city_id = c.city_id
    WHERE c.state_ut_code = p_state_ut_code
    GROUP BY f.status;
END //
DELIMITER ;

#7. Show all incidents where recovery percentage < 50%
DELIMITER //
CREATE PROCEDURE LowRecoveryCases()
BEGIN
    SELECT 
        f.incident_id,
        f.loss_amount,
        f.recovered_amount,
        ROUND((f.recovered_amount / f.loss_amount) * 100, 2) AS recovery_percentage,
        f.status
    FROM fact_cybercrime_incident f
    WHERE f.loss_amount > 0
      AND (f.recovered_amount / f.loss_amount) * 100 < 50;
END //
DELIMITER ;

#8. Show the most frequently used modus_operandi
DELIMITER //
CREATE PROCEDURE MostCommonModusOperandi()
BEGIN
    SELECT 
        ct.modus_operandi,
        COUNT(*) AS occurrence_count
    FROM fact_cybercrime_incident f
    JOIN dim_crime_type ct ON f.crime_type_id = ct.crime_type_id
    WHERE ct.modus_operandi IS NOT NULL AND ct.modus_operandi <> ''
    GROUP BY ct.modus_operandi
    ORDER BY occurrence_count DESC
    LIMIT 1;
END //
DELIMITER ;


#9. Display all cases handled in a particular year
DELIMITER //
CREATE PROCEDURE IncidentsByYear(IN p_year INT)
BEGIN
    SELECT *
    FROM fact_cybercrime_incident
    WHERE YEAR(incident_date) = p_year;
END //
DELIMITER ;

#10. Count crimes committed per education_level of victims
DELIMITER //
CREATE PROCEDURE CrimesByEducationLevel()
BEGIN
    SELECT 
        v.education_level,
        COUNT(*) AS total_cases
    FROM fact_cybercrime_incident f
    JOIN dim_victim v ON f.victim_id = v.victim_id
    GROUP BY v.education_level
    ORDER BY total_cases DESC;
END //
DELIMITER ;



CALL FullIncidentDetails();
CALL CrimesByCategory('Financial Fraud');
CALL VictimsWithLocation();
CALL DeviceTypeUsageCount();
CALL Top3AgenciesByClosedCases();
CALL IncidentsByStatusInState('MH');
CALL LowRecoveryCases();
CALL MostCommonModusOperandi();
CALL IncidentsByYear(2023);
CALL CrimesByEducationLevel();


#IV. ANALYTICAL / INSIGHT-BASED QUERIES

#1. Calculate the recovery percentage (recovered_amount / loss_amount * 100) by state
DELIMITER //
CREATE PROCEDURE RecoveryPercentageByState()
BEGIN
    SELECT 
        s.state_ut_name,
        ROUND(
            (SUM(f.recovered_amount) / NULLIF(SUM(f.loss_amount), 0)) * 100, 
            2
        ) AS recovery_percentage
    FROM fact_cybercrime_incident f
    JOIN dim_city c ON f.city_id = c.city_id
    JOIN dim_state_ut s ON c.state_ut_code = s.state_ut_code
    GROUP BY s.state_ut_name
    ORDER BY recovery_percentage DESC;
END //
DELIMITER ;

#2. Find the state with the highest total financial loss
DELIMITER //
CREATE PROCEDURE StateWithHighestLoss()
BEGIN
    SELECT 
        s.state_ut_name,
        SUM(f.loss_amount) AS total_loss_amount
    FROM fact_cybercrime_incident f
    JOIN dim_city c ON f.city_id = c.city_id
    JOIN dim_state_ut s ON c.state_ut_code = s.state_ut_code
    GROUP BY s.state_ut_name
    ORDER BY total_loss_amount DESC
    LIMIT 1;
END //
DELIMITER ;

#3. Show total incidents per month across India
DELIMITER //
CREATE PROCEDURE IncidentsPerMonth()
BEGIN
    SELECT 
        DATE_FORMAT(incident_date, '%Y-%m') AS month,
        COUNT(*) AS total_incidents
    FROM fact_cybercrime_incident
    GROUP BY DATE_FORMAT(incident_date, '%Y-%m')
    ORDER BY month;
END //
DELIMITER ;

#4. Display top 5 cybercrime categories by total loss_amount
DELIMITER //
CREATE PROCEDURE Top5CategoriesByLoss()
BEGIN
    SELECT 
        ct.cybercrime_category,
        SUM(f.loss_amount) AS total_loss
    FROM fact_cybercrime_incident f
    JOIN dim_crime_type ct ON f.crime_type_id = ct.crime_type_id
    GROUP BY ct.cybercrime_category
    ORDER BY total_loss DESC
    LIMIT 5;
END //
DELIMITER ;

#5. Rank cities by number of reported cybercrimes (using RANK)
DELIMITER //
CREATE PROCEDURE RankCitiesByIncidents()
BEGIN
    SELECT 
        city_name,
        total_incidents,
        RANK() OVER (ORDER BY total_incidents DESC) AS rank_position
    FROM (
        SELECT 
            c.city_name,
            COUNT(*) AS total_incidents
        FROM fact_cybercrime_incident f
        JOIN dim_city c ON f.city_id = c.city_id
        GROUP BY c.city_name
    ) AS ranked_data;
END //
DELIMITER ;


CALL RecoveryPercentageByState();
CALL StateWithHighestLoss();
CALL IncidentsPerMonth();
CALL Top5CategoriesByLoss();
CALL RankCitiesByIncidents();


#V. REAL-TIME APPLICATION / ADMIN OPERATIONS

#1. Update the status of a case (inputs: incident_id, new_status)
DELIMITER //
CREATE PROCEDURE UpdateCaseStatus(
    IN p_incident_id VARCHAR(30),
    IN p_new_status VARCHAR(50)
)
BEGIN
    UPDATE fact_cybercrime_incident
    SET status = p_new_status
    WHERE incident_id = p_incident_id;

    SELECT 
        CONCAT('Case ', p_incident_id, ' updated successfully to status: ', p_new_status) AS message;
END //
DELIMITER ;




#2. Insert a new record into dim_victim table
DELIMITER //
CREATE PROCEDURE InsertNewVictim(
    IN p_victim_id VARCHAR(20),
    IN p_age INT,
    IN p_gender ENUM('Male','Female','Other'),
    IN p_occupation VARCHAR(100),
    IN p_income_group VARCHAR(50),
    IN p_education_level VARCHAR(100)
)
BEGIN
    INSERT INTO dim_victim (
        victim_id, age, gender, occupation, income_group, education_level
    )
    VALUES (
        p_victim_id, p_age, p_gender, p_occupation, p_income_group, p_education_level
    );

    SELECT 
        CONCAT('New victim inserted successfully with ID: ', p_victim_id) AS message;
END //
DELIMITER ;


#3. Update the is_vpn_used flag in dim_device (input: device_id, flag_value)
DELIMITER //
CREATE PROCEDURE UpdateVPNFlag(
    IN p_device_id VARCHAR(20),
    IN p_flag ENUM('Yes','No')
)
BEGIN
    UPDATE dim_device
    SET is_vpn_used = p_flag
    WHERE device_id = p_device_id;

    SELECT 
        CONCAT('VPN usage flag updated to ', p_flag, ' for device ID: ', p_device_id) AS message;
END //
DELIMITER ;



CALL UpdateCaseStatus('INC_PUN_20241230_00002', 'Resolved');
CALL InsertNewVictim('VC_M_29_1100', 29, 'Male', 'Engineer', 'Upper-Middle', 'Postgraduate');
CALL UpdateVPNFlag('DV_WINDOW_003', 'No');



SELECT *
FROM fact_cybercrime_incident
WHERE loss_amount = 0;


SELECT COUNT(*) AS zero_loss_cases
FROM fact_cybercrime_incident
WHERE loss_amount = 0;




SELECT status, COUNT(*) AS total_cases
FROM fact_cybercrime_incident
GROUP BY status;


SELECT *
FROM fact_cybercrime_incident
WHERE status = "open";


select * from fact_cybercrime_incident;

select * from fact_cybercrime_incident where status="in progress";



SELECT * 
FROM fact_cybercrime_incident
WHERE REPLACE(REPLACE(REPLACE(status, '\r', ''), '\n', ''), '\t', '') = 'in progress';

SELECT * 
FROM fact_cybercrime_incident
WHERE REPLACE(REPLACE(REPLACE(status, '\r', ''), '\n', ''), '\t', '') = 'closed';

SELECT * 
FROM fact_cybercrime_incident
WHERE REPLACE(REPLACE(REPLACE(status, '\r', ''), '\n', ''), '\t', '') = 'open';


UPDATE fact_cybercrime_incident
SET status = TRIM(LOWER(REPLACE(REPLACE(REPLACE(status, '\r', ''), '\n', ''), '\t', '')));

SET SQL_SAFE_UPDATES = 0;

UPDATE fact_cybercrime_incident
SET status = TRIM(LOWER(REPLACE(REPLACE(REPLACE(status, '\r', ''), '\n', ''), '\t', '')));

SET SQL_SAFE_UPDATES = 1;




select * from fact_cybercrime_incident where status="closed";
select * from fact_cybercrime_incident where status="open";
select * from fact_cybercrime_incident where status="in progress";
select * from fact_cybercrime_incident where status="resolved";

#NEW STORED PROCEDURES
#1

DELIMITER //

CREATE PROCEDURE IncidentsPerYear()
BEGIN
    SELECT 
        YEAR(incident_date) AS year,
        COUNT(*) AS total_incidents
    FROM fact_cybercrime_incident
    WHERE incident_date IS NOT NULL
    GROUP BY YEAR(incident_date)
    ORDER BY YEAR(incident_date);
END //

DELIMITER ;

CALL IncidentsPerYear();

#2 Top 5 Agencies That Closed the Most Cases
DELIMITER //

CREATE PROCEDURE Top5AgenciesByClosedCases()
BEGIN
    SELECT 
        a.investigating_agency,
        COUNT(f.incident_id) AS closed_cases
    FROM fact_cybercrime_incident AS f
    JOIN dim_agency AS a
        ON a.agency_id = f.agency_id
    WHERE TRIM(LOWER(f.status)) = 'closed'
    GROUP BY a.investigating_agency
    ORDER BY closed_cases DESC, a.investigating_agency
    LIMIT 5;
END //

DELIMITER ;

CALL Top5AgenciesByClosedCases();




#3 Top 5 States with Highest Cybercrime Incidents
DELIMITER //

CREATE PROCEDURE Top5StatesByIncidents()
BEGIN
    SELECT 
        s.state_ut_name AS state_name,
        COUNT(f.incident_id) AS total_cases
    FROM fact_cybercrime_incident AS f
    JOIN dim_city AS c
        ON c.city_id = f.city_id
    JOIN dim_state_ut AS s
        ON s.state_ut_code = c.state_ut_code
    WHERE TRIM(LOWER(s.`type`)) = 'state'
    GROUP BY s.state_ut_name
    ORDER BY total_cases DESC, s.state_ut_name
    LIMIT 5;
END //

DELIMITER ;

CALL Top5StatesByIncidents();


#4 Top 5 Union Territories by Cybercrime Incidents
DELIMITER //

CREATE PROCEDURE Top5UTsByIncidents()
BEGIN
    SELECT 
        s.state_ut_name AS ut_name,
        COUNT(f.incident_id) AS total_cases
    FROM fact_cybercrime_incident AS f
    JOIN dim_city AS c
        ON c.city_id = f.city_id
    JOIN dim_state_ut AS s
        ON s.state_ut_code = c.state_ut_code
    WHERE TRIM(LOWER(s.`type`)) IN ('ut', 'union territory')
    GROUP BY s.state_ut_name
    ORDER BY total_cases DESC, s.state_ut_name
    LIMIT 5;
END //

DELIMITER ;

CALL Top5UTsByIncidents();

#5 Age Group Most Affected by Cybercrimes
DELIMITER //

CREATE PROCEDURE MostAffectedAgeGroup()
BEGIN
    SELECT 
        CASE
            WHEN v.age IS NULL THEN 'Unknown'
            WHEN v.age < 18 THEN 'Under 18'
            WHEN v.age BETWEEN 18 AND 25 THEN '18–25'
            WHEN v.age BETWEEN 26 AND 35 THEN '26–35'
            WHEN v.age BETWEEN 36 AND 45 THEN '36–45'
            WHEN v.age BETWEEN 46 AND 60 THEN '46–60'
            ELSE '60+'
        END AS age_group,
        COUNT(f.incident_id) AS total_cases
    FROM fact_cybercrime_incident AS f
    JOIN dim_victim AS v
        ON v.victim_id = f.victim_id
    GROUP BY age_group
    ORDER BY total_cases DESC, age_group
    LIMIT 1;
END //

DELIMITER ;

CALL MostAffectedAgeGroup();

# 6 Top 5 States by Average Loss Amount

DELIMITER //

CREATE PROCEDURE Top5StatesByAvgLoss()
BEGIN
    SELECT 
        s.state_ut_name AS state_name,
        ROUND(AVG(f.loss_amount), 2) AS avg_loss_amount
    FROM fact_cybercrime_incident AS f
    JOIN dim_city AS c
        ON c.city_id = f.city_id
    JOIN dim_state_ut AS s
        ON s.state_ut_code = c.state_ut_code
    WHERE TRIM(LOWER(s.`type`)) = 'state'
      AND f.loss_amount IS NOT NULL
    GROUP BY s.state_ut_name
    ORDER BY avg_loss_amount DESC, s.state_ut_name
    LIMIT 5;
END //

DELIMITER ;


CALL Top5StatesByAvgLoss();




CALL IncidentsPerYear();
CALL Top5AgenciesByClosedCases();
CALL Top5StatesByIncidents();
CALL Top5UTsByIncidents();
CALL MostAffectedAgeGroup();
CALL Top5StatesByAvgLoss();


DELIMITER //
CREATE PROCEDURE CrimesByOccupation()
BEGIN
    SELECT 
        v.occupation,
        COUNT(f.incident_id) AS total_cases
    FROM fact_cybercrime_incident f
    JOIN dim_victim v ON f.victim_id = v.victim_id
    GROUP BY v.occupation
    ORDER BY total_cases DESC;
END //
DELIMITER ;

CALL CrimesByOccupation();



DELIMITER //

CREATE PROCEDURE MostCommonModusOperandiTopN(IN p_limit INT)
BEGIN
  -- Default safeguard for NULL or invalid limit
  IF p_limit IS NULL OR p_limit < 1 THEN
    SET p_limit = 10;
  END IF;

  SELECT
    ct.modus_operandi,
    COUNT(*) AS occurrence_count
  FROM fact_cybercrime_incident f
  JOIN dim_crime_type ct ON f.crime_type_id = ct.crime_type_id
  WHERE ct.modus_operandi IS NOT NULL
    AND TRIM(ct.modus_operandi) <> ''
  GROUP BY ct.modus_operandi
  ORDER BY occurrence_count DESC
  LIMIT p_limit;
END //

DELIMITER ;

CALL MostCommonModusOperandiTopN(5);   -- Returns top 5 modus operandi
CALL MostCommonModusOperandiTopN(NULL);  -- Defaults to top 10



DELIMITER //

CREATE PROCEDURE Top5ModusOperandi()
BEGIN
  SELECT
    ct.modus_operandi AS Modus_Operandi,
    COUNT(*) AS Occurrence_Count
  FROM fact_cybercrime_incident f
  JOIN dim_crime_type ct
      ON f.crime_type_id = ct.crime_type_id
  WHERE ct.modus_operandi IS NOT NULL
    AND TRIM(ct.modus_operandi) <> ''
  GROUP BY ct.modus_operandi
  ORDER BY Occurrence_Count DESC
  LIMIT 5;
END //

DELIMITER ;

CALL Top5ModusOperandi();























































































































































































